const { defineConfig } = require('cypress')

module.exports = defineConfig({
  e2e: {
    baseUrl: 'https://notes-serverless-app.com',
    // eslint-disable-next-line no-unused-vars
    setupNodeEvents(on, config) {
    },
  },
})
