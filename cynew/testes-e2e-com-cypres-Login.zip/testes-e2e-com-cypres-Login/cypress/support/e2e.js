import 'cypress-mailosaur'

import './commands'

