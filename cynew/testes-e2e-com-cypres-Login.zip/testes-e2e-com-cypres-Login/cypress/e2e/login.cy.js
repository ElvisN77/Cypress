/* eslint-disable cypress/no-unnecessary-waiting */
// cypress/e2e/login.cy.js

describe('Login', () => {
  it('successfully logs in', () => {
    cy.intercept('GET', '**/notes').as('getNotes')

    //cy.visit('/login')
    //cy.get('#email').type(Cypress.env('USER_EMAIL'))
    //cy.get('#password').type(Cypress.env('USER_PASSWORD'))
    //cy.get('#password').type(Cypress.env('USER_PASSWORD'), { log: false })
    //cy.contains('button', 'Login').click()
    cy.login()
    cy.wait(10000)
    cy.wait('@getNotes')

    //cy.contains('h1', 'Your Notes').should('be.visible')
    //cy.contains('h4', 'Create a new note').should('be.visible')
    //cy.wait(10000)
    cy.contains('h4', 'Create a new note').click()
    //cy.contains('//*[@id="content"]')
    cy.wait(10000)
    //cy.contains('#content').should('be.visible')
    //cy.contains('//*[@id="root"]/div/nav/div/div[1]/a').click()
    //cy.contains('textarea').click()
    cy.get('textarea').type('Hello world  new test.....QA')
    cy.contains('button', 'Create').click()
    cy.wait(10000)
    //cy.contains('//*[@id="root"]/div/div').click()
  })
})



